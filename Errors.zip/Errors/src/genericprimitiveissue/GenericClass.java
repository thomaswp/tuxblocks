package genericprimitiveissue;

public class GenericClass<T> {
	public void add(T item) {
		System.out.println("Added: " + item);
	}
}
