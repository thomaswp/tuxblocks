
public class Main {
	public static void main(String[] args) {
		testAnonymousClassIssue();
		testNestedClassIssue();
		test2DArrayIssue();
		testGenericPrimitiveIssue();
		testGenericDuplicateIssue();
		testImportIssue();
	}
	
	private static void testAnonymousClassIssue() {
		startTest("Anonymous Class Issue");
		String out = anonymousclassissue.BaseClass.bar().foo();
		System.out.println("Output should be 'Hello!'");
		System.out.println("Output: " + out);
	}
	
	private static void testNestedClassIssue() {
		startTest("Nested Class Issue");
		String out = nestedclassissue.BaseClass.bar().foo();
		System.out.println("Output should be 'Hello!'");
		System.out.println("Output: " + out);
	}
	
	private static void test2DArrayIssue() {
		startTest("2D Array Issue");
		System.out.println("Output should be 'Arrays successfully created!'");
		twodarrayissue.ClassWithArrays.foo(3, 4);
	}
	
	private static void testGenericPrimitiveIssue() {
		startTest("Generic Primitive Issue");
		System.out.println("Output should be 'Added 3.0'");
		genericprimitiveissue.DerivedClass c = new genericprimitiveissue.DerivedClass();
		c.add(5f);
	}
	
	private static void testGenericDuplicateIssue() {
		startTest("Generic Duplicate Issue");
		System.out.println("Output should be 'Create with Foo \\ Create with Bar'");
		genericduplicateissue.Foo foo = new genericduplicateissue.Foo();
		genericduplicateissue.Bar bar = new genericduplicateissue.Bar();
		genericduplicateissue.GenericClass.create(foo);
		genericduplicateissue.GenericClass.create(bar);	
	}
	
	private static void testImportIssue() {
		startTest("Import Issue");
		importissue.DerivedClass c = new importissue.DerivedClass();
		System.out.println("Output should be 'foo.x = 3'");
		c.checkFoo();
	}
	
	private static void startTest(String test) {
		System.out.println("\n===========================");
		System.out.println("Starting test: " + test);
	}
}
