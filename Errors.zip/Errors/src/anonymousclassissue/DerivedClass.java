package anonymousclassissue;

public abstract class DerivedClass extends BaseClass  {
}
