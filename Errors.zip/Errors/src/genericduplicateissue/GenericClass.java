package genericduplicateissue;

public class GenericClass {
	public static <T extends Foo> void create(T foo) {
		System.out.println("Create with Foo");
	}
	
	public static <T extends Bar> void create(T bar) {
		System.out.println("Create with Bar");
	}
}
