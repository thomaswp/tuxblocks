package genericprimitiveissue;

public class DerivedClass extends GenericClass<Float> {
	@Override
	public void add(Float f) {
		super.add(three());
	}
	
	private float three() { return 3; }
}
