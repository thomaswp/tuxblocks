package importissue;

public class Foo {
	public int x;
}
