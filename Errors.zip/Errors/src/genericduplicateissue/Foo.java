package genericduplicateissue;

public class Foo {

}
