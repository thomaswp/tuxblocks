package nestedclassissue;

public abstract class DerivedClass extends BaseClass  {
}
