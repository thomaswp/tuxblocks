package genericprimitiveissue;

public class DerivedClass extends GenericClass<Float> {
	public void test() {
		add(3f);
	}
}
