package nestedclassissue;

public abstract class BaseClass {

	public abstract String foo();
	
	public static BaseClass bar() {
		return new MyDerivedClass();
	}
	
	private static class MyDerivedClass extends DerivedClass {
		@Override
		public String foo() {
			return "Hello!";
		}
	}
}
