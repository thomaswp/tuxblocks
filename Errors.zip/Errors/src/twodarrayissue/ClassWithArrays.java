package twodarrayissue;

public class ClassWithArrays {

	public static void foo(int dim1, int dim2) {
		int[][] intArray = new int[dim1][];
		boolean[][] boolArray = new boolean[dim1][dim2];
		
		intArray[0] = new int[1];
		boolArray[0][0] = true;
		
		System.out.println("Arrays successfully created!");
	}
	
}
