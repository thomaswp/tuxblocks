package importissue;

public class BaseClass {
	protected Foo foo = new Foo();
	
	public BaseClass() {
		foo.x = 3;
	}
}
