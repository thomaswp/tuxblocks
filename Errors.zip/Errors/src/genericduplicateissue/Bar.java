package genericduplicateissue;

public class Bar {

}
