package anonymousclassissue;

public abstract class BaseClass {

	public abstract String foo();
	
	public static BaseClass bar() {
		//Having an anonymous derived class in the superclass is a problem
		return new DerivedClass() {
			@Override
			public String foo() {
				return "Hello!";
			}
		};
	}
}
