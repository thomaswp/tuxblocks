package importissue;

public class DerivedClass extends BaseClass{

	public void checkFoo() {
		System.out.println("foo.x = " + foo.x);
	}
	
}
